'use strict';

var AWS = require("aws-sdk");

const _archiver = require('archiver');
const axios = require('axios');
AWS.config.region = 'us-west-2';
var lambda = new AWS.Lambda();

const streamTo = (_bucket, _key, s3) => {
    var stream = require('stream');
    var _pass = new stream.PassThrough();
    s3.upload({ Bucket: _bucket, Key: _key, Body: _pass }, (_err, _data) => { /*...Handle Errors Here*/ });
    return _pass;
};


exports.handler = async(event) => {
    var keys = [];
    var bucket_name = event.bucket_name;
    
    var folder = event.folder;

    var continuationToken = null;

    var sourceFiles = [];
    
    var s3 = new AWS.S3({ region: 'us-east-1' });

    while (true) {
        let s3Objects = await s3.listObjectsV2({ Bucket: bucket_name, Prefix: folder, ContinuationToken: continuationToken }).promise();
        continuationToken = s3Objects.NextContinuationToken;
        sourceFiles = sourceFiles.concat(s3Objects.Contents.map(content => { return content.Key; }).filter(k => k != `${folder}/`));
        if (!s3Objects.IsTruncated) {
            break;
        }
    }

    var _keys = sourceFiles;

    var _list = await Promise.all(_keys.map(_key => new Promise((_resolve, _reject) => {
        s3.getObject({ Bucket: bucket_name, Key: _key }, function(err, data){
            if (err) console.log(err);
            else _resolve({ data: data.Body, name: `${_key.split('/').pop()}` });
        });
    })));

    await new Promise((_resolve, _reject) => {
        var _myStream = streamTo(bucket_name, folder + '/backup.zip', s3);
        var _archive = _archiver('zip');
        _archive.on('error', err => { throw new Error(err); });

        _myStream.on('close', _resolve);
        _myStream.on('end', _resolve);
        _myStream.on('error', _reject);

        _archive.pipe(_myStream);
        _list.forEach(_itm => _archive.append(_itm.data, { name: _itm.name }));
        _archive.finalize();
    }).catch(_err => { throw new Error(_err) });
    
    var ret = {
        file_name: folder + "/backup.zip",
        backup_id: event.backup_id,
        segment_id: event.segment_id
    }
    
    var response = {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
        },
        body: (ret),
    };
    
    await axios({
      method: 'post',
      url: event.returnurl,
      data: ret
    });
    
    return response;
    
};